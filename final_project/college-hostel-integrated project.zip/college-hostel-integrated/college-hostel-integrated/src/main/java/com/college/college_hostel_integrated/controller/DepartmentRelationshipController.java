package com.college.college_hostel_integrated.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.college.college_hostel_integrated.model.Course;
import com.college.college_hostel_integrated.repository.CourseRepository;

import com.college.college_hostel_integrated.model.Teacher;
import com.college.college_hostel_integrated.repository.TeacherRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(
	    name = "Department Relationships APIs",
	    description = "Department Relationships Management"
	)
@RestController
@RequestMapping("/departments")
public class DepartmentRelationshipController {

    @Autowired
    private CourseRepository courseRepository;
    @Autowired
    private TeacherRepository teacherRepository;

    @Operation(
    	    summary = "Get courses in a department by department id"
    	)
    @GetMapping("/{departmentId}/courses")
    public List<Course> getCoursesByDepartment(
            @PathVariable String departmentId) {

        return courseRepository.findByDepartmentId(departmentId);
    }
    
    @Operation(
    	    summary = "Get teachers in a department by department id"
    	)
    @GetMapping("/{departmentId}/teachers")
    public List<Teacher> getTeachersByDepartment(
            @PathVariable String departmentId){

        return teacherRepository
                .findByDepartmentId(departmentId);
    }
    
}

