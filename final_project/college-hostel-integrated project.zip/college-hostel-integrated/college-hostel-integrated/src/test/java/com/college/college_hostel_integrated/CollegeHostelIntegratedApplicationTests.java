package com.college.college_hostel_integrated;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeHostelIntegratedApplicationTests {

	@Test
	void contextLoads() {
	}

}
