package com.college.college_hostel_integrated;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeHostelIntegratedApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeHostelIntegratedApplication.class, args);
	}

}