package com.college.college_hostel_integrated.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.college.college_hostel_integrated.model.Student;
import com.college.college_hostel_integrated.repository.StudentRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(
	    name = "Course Relationships APIs",
	    description = "Course Relationships Management"
	)
@RestController
@RequestMapping("/courses")
public class CourseRelationshipController {

    @Autowired
    private StudentRepository studentRepository;
    
    @Operation(
    	    summary = "Get students in a course by course id"
    	)
    @GetMapping("/{courseId}/students")
    public List<Student> getStudentsByCourse(
            @PathVariable String courseId){

        return studentRepository
                .findByCourseId(courseId);
    }

}

