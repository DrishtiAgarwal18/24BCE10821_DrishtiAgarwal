package com.college.college_hostel_integrated.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.college.college_hostel_integrated.model.Department;

public interface DepartmentRepository
        extends MongoRepository<Department, String> {
}