package com.college.college_hostel_integrated.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.college.college_hostel_integrated.model.Room;

public interface RoomRepository
        extends MongoRepository<Room, String> {
}