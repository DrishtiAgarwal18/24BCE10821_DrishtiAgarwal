package com.college.college_hostel_integrated.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import io.swagger.v3.oas.annotations.Operation;

import com.college.college_hostel_integrated.model.Department;
import com.college.college_hostel_integrated.repository.DepartmentRepository;

@Tag(
	    name = "Department APIs",
	    description = "Department Management"
	)	
@RestController
@RequestMapping("/departments")
public class DepartmentController {

    @Autowired
    DepartmentRepository repository;
    @Operation(
    	    summary = "Creates a department"
    	)
    @PostMapping
    public Department addDepartment(
            @Valid @RequestBody Department department) {

        return repository.save(department);
    }
    
    @Operation(
    	    summary = "Get all departments",
    	    description = "Returns all departments from MongoDB"
    	)
    @GetMapping
    public List<Department> getDepartments() {
        return repository.findAll();
    }
    @Operation(
    	    summary = "Get departments by id",
    	    description = "Returns departments by id from MongoDB"
    	)
    @GetMapping("/{id}")
    public Department getDepartmentById(@PathVariable String id) {
        return repository.findById(id).orElseThrow(() ->
        new RuntimeException("Department not found"));
    }
    @Operation(
    	    summary = "Delete departments by id",
    	    description = "Deletes departments by id from MongoDB"
    	)
    @DeleteMapping("/{id}")
    public String deleteDepartment(@PathVariable String id) {
        repository.deleteById(id);
        return "Department Deleted";
    }
    @Operation(
    	    summary = "Update departments by id",
    	    description = "Update departments by id from MongoDB"
    	)
    @PutMapping("/{id}")
    public Department updateDepartment(
            @PathVariable String id,
            @RequestBody Department updatedDepartment) {

        Department department =
                repository.findById(id).orElseThrow(() ->
                new RuntimeException("Department not found"));

        if(department != null) {
        	department.setDepartmentName(
        		    updatedDepartment.getDepartmentName()
        		);

            return repository.save(department);
        }

        return null;
    }
}
