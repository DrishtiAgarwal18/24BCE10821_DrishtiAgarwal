package com.college.college_hostel_integrated.dto;

public class ComplaintCountByPriority {

    private String priority;
    private int count;

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
