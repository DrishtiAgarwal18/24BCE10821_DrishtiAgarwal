package com.college.college_hostel_integrated.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.college.college_hostel_integrated.model.Complaint;

import java.util.List;

public interface ComplaintRepository
        extends MongoRepository<Complaint, String> {
	List<Complaint> findByStudentId(String studentId);
	List<Complaint> findByPriority(String priority);
}