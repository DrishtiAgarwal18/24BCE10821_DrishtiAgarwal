package com.college.college_hostel_integrated.dto;

public class Dashboard {
	
	private long totalStudents;
	private long totalTeachers;
	private long totalCourses;
	private long totalDepartments;
	private long totalRooms;
	
	public long getTotalStudents() {
		return  totalStudents;
	}
	public void setTotalStudents(long totalStudents) {
		this.totalStudents = totalStudents;
	}
	public long getTotalTeachers() {
		return totalTeachers;
	}
	public void setTotalTeachers(long totalTeachers) {
		this.totalTeachers = totalTeachers;
	}
	public long getTotalCourses() {
		return totalCourses;
	}
	public void setTotalCourses(long totalCourses) {
		this.totalCourses = totalCourses;
	}
	public long getTotalDepartments() {
		return totalDepartments;
	}
	public void setTotalDepartments(long totalDepartments) {
		this.totalDepartments = totalDepartments;
	}
	public long getTotalRooms() {
		return totalRooms;
	}
	public void setTotalRooms(long totalRooms) {
		this.totalRooms = totalRooms;
	}
	
}
