package com.college.college_hostel_integrated.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.college.college_hostel_integrated.model.Course;

import java.util.List;

public interface CourseRepository extends MongoRepository<Course, String> {

    List<Course> findByDepartmentId(String departmentId);

}