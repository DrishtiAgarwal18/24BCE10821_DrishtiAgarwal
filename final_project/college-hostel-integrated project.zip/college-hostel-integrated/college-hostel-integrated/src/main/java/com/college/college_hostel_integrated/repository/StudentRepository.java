package com.college.college_hostel_integrated.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.college.college_hostel_integrated.model.Student;

import java.util.List;

public interface StudentRepository
        extends MongoRepository<Student, String> {
	
	List<Student> findByCourseId(String courseId);
	List<Student> findByRoomId(String roomId);
	
}