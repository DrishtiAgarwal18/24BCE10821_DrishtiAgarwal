package com.college.college_hostel_integrated.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.college.college_hostel_integrated.model.Teacher;
import com.college.college_hostel_integrated.repository.TeacherRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@Tag(
	    name = "Teacher APIs",
	    description = "Teacher Management"
	)	
@RestController
@RequestMapping("/teachers")
public class TeacherController {

    @Autowired
    TeacherRepository repository;
    @Operation(
    	    summary = "Creates a teacher"
    	)
    @PostMapping
    public Teacher addTeacher(
            @Valid @RequestBody Teacher teacher) {

        return repository.save(teacher);
    }
    
    @Operation(
    	    summary = "Get all teachers",
    	    description = "Returns all teachers from MongoDB"
    	)
    @GetMapping
    public List<Teacher> getTeachers() {
        return repository.findAll();
    }
    @Operation(
    	    summary = "Get teachers by id",
    	    description = "Returns teachers by id from MongoDB"
    	)
    @GetMapping("/{id}")
    public Teacher getTeacherById(@PathVariable String id) {
        return repository.findById(id).orElseThrow(() ->
        new RuntimeException("Teacher not found"));
    }
    @Operation(
    	    summary = "Delete teachers by id",
    	    description = "Deletes teachers by id from MongoDB"
    	)
    @DeleteMapping("/{id}")
    public String deleteTeacher(@PathVariable String id) {
        repository.deleteById(id);
        return "Teacher Deleted";
    }
    @Operation(
    	    summary = "Update teachers by id",
    	    description = "Updates teachers by id from MongoDB"
    	)
    @PutMapping("/{id}")
    public Teacher updateTeacher(
            @PathVariable String id,
            @RequestBody Teacher updatedTeacher) {

        Teacher teacher =
                repository.findById(id).orElseThrow(() ->
                new RuntimeException("Teacher not found"));

        if(teacher != null) {
        	if(updatedTeacher.getName() != null) {
        	    teacher.setName(
        	            updatedTeacher.getName());
        	}

        	if(updatedTeacher.getDepartmentId() != null) {
        	    teacher.setDepartmentId(
        	            updatedTeacher.getDepartmentId());
        	}

            return repository.save(teacher);
        }

        return null;
    }
}
