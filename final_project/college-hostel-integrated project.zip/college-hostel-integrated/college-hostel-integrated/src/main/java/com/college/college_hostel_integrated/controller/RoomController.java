package com.college.college_hostel_integrated.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.college.college_hostel_integrated.model.Room;
import com.college.college_hostel_integrated.repository.RoomRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@Tag(
	    name = "Room APIs",
	    description = "Room Management"
	)	
@RestController
@RequestMapping("/rooms")
public class RoomController {

    @Autowired
    RoomRepository repository;
    @Operation(
    	    summary = "Creates a room"
    	)
    @PostMapping
    public Room addRoom(
            @Valid @RequestBody Room room) {

        return repository.save(room);
    }
    
    @Operation(
    	    summary = "Get all rooms",
    	    description = "Returns all rooms from MongoDB"
    	)
    @GetMapping
    public List<Room> getRooms() {
        return repository.findAll();
    }
    
    @Operation(
    	    summary = "Get rooms by id",
    	    description = "Returns rooms by id from MongoDB"
    	)

    @GetMapping("/{id}")
    public Room getRoomById(@PathVariable String id) {
        return repository.findById(id).orElseThrow(() ->
        new RuntimeException("Room not found"));
    }
    
    @Operation(
    	    summary = "Delete rooms by id",
    	    description = "Deletes rooms by id from MongoDB"
    	)
    
    @DeleteMapping("/{id}")
    public String deleteRoom(@PathVariable String id) {
        repository.deleteById(id);
        return "Room Deleted";
    }
    @Operation(
    	    summary = "Update rooms by id",
    	    description = "Updates rooms by id from MongoDB"
    	)
    @PutMapping("/{id}")
    public Room updateRoom(
            @PathVariable String id,
            @RequestBody Room updatedRoom) {

        Room room =
                repository.findById(id).orElseThrow(() ->
                new RuntimeException("Room not found"));

        if(room != null) {
        	if(updatedRoom.getRoomNo()!=null) {
        	room.setRoomNo(updatedRoom.getRoomNo());
        	}
        	if(updatedRoom.getCapacity()!=null) {
        		room.setCapacity(updatedRoom.getCapacity());
        	}
        	return repository.save(room);     
        }

        return null;
    }
}
