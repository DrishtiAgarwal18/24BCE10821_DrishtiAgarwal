package com.college.college_hostel_integrated.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.college.college_hostel_integrated.model.Complaint;
import com.college.college_hostel_integrated.repository.ComplaintRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(
	    name = "Student Relationships APIs",
	    description = "Student Relationships Management"
	)
@RestController
@RequestMapping("/students")
public class StudentRelationshipController {

    @Autowired
    private ComplaintRepository complaintRepository;
    
    @Operation(
    	    summary = "Get complaints by a student by student id"
    	)
    @GetMapping("/{studentId}/complaints")
    public List<Complaint> getComplaintsByStudents(
            @PathVariable String studentId){

        return complaintRepository
                .findByStudentId(studentId);
    }

}


