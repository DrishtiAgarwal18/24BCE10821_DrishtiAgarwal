package com.college.college_hostel_integrated.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.NotBlank;

@Document(collection = "complaints")
public class Complaint {

    @Id
    private String id;
    @NotBlank(message = "Complaint title is required")
    private String title;
    private String description;
    @NotBlank(message = "Student ID is required")
    private String studentId;
    private String status;
    private String priority;

    public Complaint() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public String getStatus() {
    	return status;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }
    
    public void setStatus(String status) {
    	this.status = status;    
    }

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}
}