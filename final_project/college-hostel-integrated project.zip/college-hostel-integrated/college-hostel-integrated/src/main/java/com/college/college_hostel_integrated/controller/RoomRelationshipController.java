package com.college.college_hostel_integrated.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.college.college_hostel_integrated.model.Student;
import com.college.college_hostel_integrated.repository.StudentRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(
	    name = "Room Relationships APIs",
	    description = "Room Relationships Management"
	)
@RestController
@RequestMapping("/rooms")
public class RoomRelationshipController {

    @Autowired
    private StudentRepository studentRepository;
    
    @Operation(
    	    summary = "Get students in a room by room id"
    	)
    @GetMapping("/{roomId}/students")
    public List<Student> getStudentsByRoom(
            @PathVariable String roomId){

        return studentRepository
                .findByRoomId(roomId);
    }

}

