package com.college.college_hostel_integrated.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.college.college_hostel_integrated.model.Student;
import com.college.college_hostel_integrated.model.Room;
import com.college.college_hostel_integrated.repository.StudentRepository;
import com.college.college_hostel_integrated.repository.RoomRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@Tag(
	    name = "Student APIs",
	    description = "Student Management"
	)	
@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    StudentRepository repository;
    
    @Autowired
    private RoomRepository roomRepository;
    
    @Operation(
    	    summary = "Creates a student"
    	)
    @PostMapping
    public Object addStudent(
            @Valid @RequestBody Student student){

        Room room =
                roomRepository
                .findById(student.getRoomId())
                .orElse(null);

        if(room == null){
            return "Room does not exist";
        }

        int occupied =
                repository
                .findByRoomId(student.getRoomId())
                .size();

        if(occupied >= room.getCapacity()){
            return "Room Full";
        }
        		
        return repository.save(student);
    }
    @Operation(
    		summary = "Allocates a room whilst creating a student automatically"
    		)
    @PostMapping("/room-allocate")
    public String autoroomAllocate( @RequestBody Student student) {
    	List <Room> rooms = roomRepository.findAll();
    	for(Room room : rooms) {
    		int occupied = repository.findByRoomId(room.getId()).size();
    		if(occupied < room.getCapacity()) {
    			student.setRoomId(room.getId());
    			repository.save(student);
    			return "Room " + room.getRoomNo() +" allocated to student "+ student.getName();    		
    			}
    		
    	}
    	Room newroom = new Room();
    	int roomCount = rooms.size();
    	newroom.setRoomNo("A10"+roomCount);
    	newroom.setCapacity(3);
    	roomRepository.save(newroom);
    	student.setRoomId(newroom.getId());
    	repository.save(student);
    	return "New Room " + newroom.getRoomNo() +" allocated to student "+ student.getName();
    	
    }
    
    @Operation(
    	    summary = "Get all students",
    	    description = "Returns all students from MongoDB"
    	)
    @GetMapping
    public List<Student> getStudents() {
        return repository.findAll();
    }
    
    @Operation(
    	    summary = "Get students by id",
    	    description = "Returns students by id from MongoDB"
    	)
    @GetMapping("/{id}")
    public Student getStudentById(@PathVariable String id) {
        return repository.findById(id).orElseThrow(() ->
        new RuntimeException("Student not found"));
    }
    
    @Operation(
    	    summary = "Delete students by id",
    	    description = "Deletes students by id from MongoDB"
    	)
    
    @DeleteMapping("/{id}")
    public String deleteStudent(@PathVariable String id) {
        repository.deleteById(id);
        return "Student Deleted";
    }
    
    @Operation(
    	    summary = "Update students by id",
    	    description = "Updates students by id from MongoDB"
    	)
    
    @PutMapping("/{id}")
    public Student updateStudent(
            @PathVariable String id,
            @RequestBody Student updatedStudent) {

        Student student =
                repository.findById(id).orElseThrow(() ->
                new RuntimeException("Student not found"));

        if(student != null) {
        	if(updatedStudent.getName() != null) {
        	    student.setName(updatedStudent.getName());
        	}

        	if(updatedStudent.getEmail() != null) {
        	    student.setEmail(updatedStudent.getEmail());
        	}
        	
        	if(updatedStudent.getCourseId() != null) {
        	    student.setCourseId(updatedStudent.getCourseId());
        	}
        	
        	if(updatedStudent.getRoomId() != null) {
        	    student.setRoomId(updatedStudent.getRoomId());
        	}
        	
            return repository.save(student);
        }

        return null;
    }
}
