package com.college.college_hostel_integrated.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.NotBlank;

@Document(collection = "teachers")
public class Teacher {

    @Id
    private String id;
    @NotBlank(message = "Teacher name is required")
    private String name;
    private String departmentId;

    public Teacher() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }
    
    public String getDepartmentId() {
        return departmentId;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }
}