package com.college.college_hostel_integrated.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.college.college_hostel_integrated.model.Course;
import com.college.college_hostel_integrated.repository.CourseRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@Tag(
	    name = "Course APIs",
	    description = "Course Management"
	)	
@RestController
@RequestMapping("/courses")
public class CourseController {

    @Autowired
    CourseRepository repository;
    @Operation(
    	    summary = "Creates a course"
    	)
    @PostMapping
    public Course addCourse(
            @Valid @RequestBody Course course) {

        return repository.save(course);
    }
    
    @Operation(
    	    summary = "Get all courses",
    	    description = "Returns all courses from MongoDB"
    	)
    @GetMapping
    public List<Course> getCourses() {
        return repository.findAll();
    }
    
    @Operation(
    	    summary = "Get courses by id",
    	    description = "Returns courses by id from MongoDB"
    	)

    @GetMapping("/{id}")
    public Course getCourseById(@PathVariable String id) {
        return repository.findById(id).orElseThrow(() ->
        new RuntimeException("Course not found"));
    }
    @Operation(
    	    summary = "Delete teachers by id",
    	    description = "Deletes teachers by id from MongoDB"
    	)
    @DeleteMapping("/{id}")
    public String deleteCourse(@PathVariable String id) {
        repository.deleteById(id);
        return "Course Deleted";
    }
    @Operation(
    	    summary = "Update teachers by id",
    	    description = "Updates teachers by id from MongoDB"
    	)
    @PutMapping("/{id}")
    public Course updateCourse(
            @PathVariable String id,
            @RequestBody Course updatedCourse) {

        Course course =
                repository.findById(id).orElseThrow(() ->
                new RuntimeException("Teacher not found"));

        if(course != null) {
        	if(updatedCourse.getCourseName() != null) {
        	    course.setCourseName(
        	            updatedCourse.getCourseName());
        	}

        	if(updatedCourse.getDepartmentId() != null) {
        	    course.setDepartmentId(
        	            updatedCourse.getDepartmentId());
        	}

            return repository.save(course);
        }

        return null;
    }
}
