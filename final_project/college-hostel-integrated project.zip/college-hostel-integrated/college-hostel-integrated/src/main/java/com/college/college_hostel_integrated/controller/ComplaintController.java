package com.college.college_hostel_integrated.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.college.college_hostel_integrated.model.Complaint;
import com.college.college_hostel_integrated.repository.ComplaintRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@Tag(
	    name = "Complaint APIs",
	    description = "Complaint Management"
	)	
@RestController
@RequestMapping("/complaints")
public class ComplaintController {

    @Autowired
    ComplaintRepository repository;
    @Operation(
    	    summary = "Creates a complaint"
    	)
    @PostMapping
    public Complaint addComplaint(
            @Valid @RequestBody Complaint complaint) {
    	
    	if(complaint.getStatus() == null){
            complaint.setStatus("Pending");
        }
    	
    	String text = complaint.getTitle().toLowerCase();
    	if(text.contains("fire")||text.contains("circuit")||text.contains("electric")||text.contains("leakage")||text.contains("security")) {
    		complaint.setPriority("High Priority");
    	}else {
    		complaint.setPriority("Low Priority");
    	}

        return repository.save(complaint);
    }
    
    @Operation(
    	    summary = "Get all complaints",
    	    description = "Returns all complaints from MongoDB"
    	)
    @GetMapping
    public List<Complaint> getComplaints() {
        return repository.findAll();
    }
    
    @Operation(
    		summary = "Get complaints by high priority"
    		) 
    @GetMapping("/highpriority")
    public List<Complaint> getHPComplaints(){
    	return repository.findByPriority("High Priority");
    }
    
    @Operation(
    		summary = "Get complaints by low priority"
    		)
    @GetMapping("/lowpriority")
    public List<Complaint> getLPComplaints(){
    	return repository.findByPriority("Low Priority");
    }
    
    @Operation(
    	    summary = "Get complaints by id",
    	    description = "Returns complaints by id from MongoDB"
    	)

    @GetMapping("/{id}")
    public Complaint getComplaintById(@PathVariable String id) {
        return repository.findById(id).orElseThrow(() ->
        new RuntimeException("Complaint not found"));
    }
    @Operation(
    	    summary = "Delete complaints by id",
    	    description = "Deletes complaints by id from MongoDB"
    	)
    @DeleteMapping("/{id}")
    public String deleteComplaint(@PathVariable String id) {
        repository.deleteById(id);
        return "Complaint Deleted";
    }
    @Operation(
    	    summary = "Update complaints by id",
    	    description = "Update complaints by id from MongoDB"
    	)
    @PutMapping("/{id}")
    public Complaint updateComplaint(
            @PathVariable String id,
            @RequestBody Complaint updatedComplaint) {

        Complaint complaint =
                repository.findById(id).orElseThrow(() ->
                new RuntimeException("Complaint not found"));

        if(complaint != null) {
        	if(updatedComplaint.getTitle() != null) {
        	    complaint.setTitle(
        	            updatedComplaint.getTitle());
        	}
        	
        	if(updatedComplaint.getDescription() != null) {
        	    complaint.setDescription(
        	            updatedComplaint.getDescription());
        	}

        	if(updatedComplaint.getStudentId() != null) {
        	    complaint.setStudentId(
        	            updatedComplaint.getStudentId());
        	}
        	
        	if(updatedComplaint.getStatus() != null) {
        	    complaint.setStatus(
        	            updatedComplaint.getStatus());
        	}

            return repository.save(complaint);
        }

        return null;
    }
    
    @Operation(
    	    summary = "Update complaints to complete by id"
    	)
    @PutMapping("/{id}/complete")
    public Complaint completeComplaint(
            @PathVariable String id){

        Complaint complaint =
                repository.findById(id)
                .orElse(null);

        if(complaint == null){
            return null;
        }

        complaint.setStatus("Completed");

        return repository.save(complaint);
    }
}
