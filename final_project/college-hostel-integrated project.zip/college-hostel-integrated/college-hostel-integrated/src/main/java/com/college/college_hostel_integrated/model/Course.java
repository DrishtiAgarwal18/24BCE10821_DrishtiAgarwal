package com.college.college_hostel_integrated.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.NotBlank;

@Document(collection = "courses")
public class Course {

    @Id
    private String id;
    @NotBlank(message = "Course name is required")
    private String courseName;
    private String departmentId;

    public Course() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCourseName() {
        return courseName;
    }
    
    public String getDepartmentId() {
        return departmentId;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
    
    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }
}