package com.college.college_hostel_integrated.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.college.college_hostel_integrated.repository.*;
import com.college.college_hostel_integrated.dto.Dashboard;

@RestController
@RequestMapping("/dashboard")
public class dashboardController {
	
	@Autowired
	private StudentRepository studentRepository;

	@Autowired
	private TeacherRepository teacherRepository;

	@Autowired
	private DepartmentRepository departmentRepository;

	@Autowired
	private CourseRepository courseRepository;

	@Autowired
	private RoomRepository roomRepository;
	
	@GetMapping
	public Dashboard getDashboard() {
		Dashboard dashboard = new Dashboard();
		
		dashboard.setTotalStudents(studentRepository.count());
		dashboard.setTotalTeachers(teacherRepository.count());
		dashboard.setTotalCourses(courseRepository.count());
		dashboard.setTotalDepartments(departmentRepository.count());
		dashboard.setTotalRooms(roomRepository.count());
		
		return dashboard;
	}

}
