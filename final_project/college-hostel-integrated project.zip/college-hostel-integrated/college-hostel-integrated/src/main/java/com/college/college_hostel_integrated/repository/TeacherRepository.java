package com.college.college_hostel_integrated.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.college.college_hostel_integrated.model.Teacher;

import java.util.List;


public interface TeacherRepository extends MongoRepository<Teacher, String> {

    List<Teacher> findByDepartmentId(String departmentId);

}