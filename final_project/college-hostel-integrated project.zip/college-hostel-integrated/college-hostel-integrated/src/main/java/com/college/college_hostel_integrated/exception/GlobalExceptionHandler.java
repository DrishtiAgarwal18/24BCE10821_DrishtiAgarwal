package com.college.college_hostel_integrated.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleValidationExceptions(
	        MethodArgumentNotValidException ex) {

	    Map<String, String> errors = new HashMap<>();

	    ex.getBindingResult()
	      .getFieldErrors()
	      .forEach(error -> {

	          errors.put(
	                  error.getField(),
	                  error.getDefaultMessage());
	      });

	    return errors;
	}
	
	@ExceptionHandler(RuntimeException.class)
	public Map<String, String> handleRuntimeException(
	        RuntimeException ex) {

	    Map<String, String> error = new HashMap<>();

	    error.put("error", ex.getMessage());

	    return error;
	}

}