package com.college.college_hostel_integrated.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import com.college.college_hostel_integrated.dto.StudentCountByCourse;
import com.college.college_hostel_integrated.dto.StudentCountByRoom;
import com.college.college_hostel_integrated.dto.TeacherCountByDepartment;
import com.college.college_hostel_integrated.dto.ComplaintCountByStatus;
import com.college.college_hostel_integrated.dto.RoomOccupancy;
import com.college.college_hostel_integrated.dto.ComplaintCountByPriority;

import com.college.college_hostel_integrated.model.Room;
import com.college.college_hostel_integrated.model.Course;
import com.college.college_hostel_integrated.model.Department;
import com.college.college_hostel_integrated.repository.CourseRepository;
import com.college.college_hostel_integrated.repository.RoomRepository;
import com.college.college_hostel_integrated.repository.DepartmentRepository;
import com.college.college_hostel_integrated.repository.StudentRepository;

import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;

import java.util.ArrayList;

@Tag(
	    name = "Analytics APIs",
	    description = "Analytic Management"
	)	
@RestController
@RequestMapping("/analytics")
public class AnalyticsController {
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Autowired
	private RoomRepository roomRepository;
	
	@Autowired
	private CourseRepository courseRepository;
	
	@Autowired
	private DepartmentRepository departmentRepository;
	
	@Autowired
	private StudentRepository studentRepository;
	
	@Operation(
    	    summary = "Get students in each course"
    	)
	@GetMapping("/students-per-course")
	public List<StudentCountByCourse> studentsPerCourse() {

	    Aggregation aggregation =
	            Aggregation.newAggregation(

	                    Aggregation.group("courseId")
	                            .count()
	                            .as("count"),

	                    Aggregation.project("count")
	                            .and("_id")
	                            .as("courseId")
	            );

	    AggregationResults<StudentCountByCourse> results =
	            mongoTemplate.aggregate(
	                    aggregation,
	                    "students",
	                    StudentCountByCourse.class);

	    List<StudentCountByCourse> aggregationResults =
	            results.getMappedResults();
	    
	    List<StudentCountByCourse> response =
	            new ArrayList<>();

	    for(StudentCountByCourse result : aggregationResults) {

	        Course course =
	                courseRepository
	                .findById(result.getCourseId())
	                .orElse(null);

	        StudentCountByCourse dto =
	                new StudentCountByCourse();

	        dto.setCourseId(result.getCourseId());
	        dto.setCount(result.getCount());

	        if(course != null) {
	            dto.setCourseName(course.getCourseName());
	        }

	        response.add(dto);
	    }

	    return response;
	}
	
	@Operation(
    	    summary = "Get students in each room"
    	)
	@GetMapping("/students-per-room")
	public List<StudentCountByRoom> studentsPerRoom() {

	    Aggregation aggregation =
	            Aggregation.newAggregation(

	                    Aggregation.group("roomId")
	                            .count()
	                            .as("count"),

	                    Aggregation.project("count")
	                            .and("_id")
	                            .as("roomId")
	            );
	    
	    

	    AggregationResults<StudentCountByRoom> results =
	            mongoTemplate.aggregate(
	                    aggregation,
	                    "students",
	                    StudentCountByRoom.class);
	    
	    List<StudentCountByRoom> aggregationResults =
	            results.getMappedResults();
	    
	    List<StudentCountByRoom> response =
	            new ArrayList<>();

	    for(StudentCountByRoom result : aggregationResults) {

	        Room room =
	                roomRepository
	                .findById(result.getRoomId())
	                .orElse(null);

	        StudentCountByRoom dto =
	                new StudentCountByRoom();

	        dto.setRoomId(result.getRoomId());
	        dto.setCount(result.getCount());

	        if(room != null) {
	            dto.setRoomNumber(room.getRoomNo());
	        }

	        response.add(dto);
	    }

	    return response;
	}
	
	@Operation(
    	    summary = "Get teachers in each department"
    	)
	@GetMapping("/teachers-per-department")
	public List<TeacherCountByDepartment> teachersPerDepartment() {

	    Aggregation aggregation =
	            Aggregation.newAggregation(

	                    Aggregation.group("departmentId")
	                            .count()
	                            .as("count"),

	                    Aggregation.project("count")
	                            .and("_id")
	                            .as("departmentId")
	            );

	    AggregationResults<TeacherCountByDepartment> results =
	            mongoTemplate.aggregate(
	                    aggregation,
	                    "teachers",
	                    TeacherCountByDepartment.class);

	    List<TeacherCountByDepartment> aggregationResults =
	            results.getMappedResults();
	    
	    List<TeacherCountByDepartment> response =
	            new ArrayList<>();

	    for(TeacherCountByDepartment result : aggregationResults) {

	        Department department =
	                departmentRepository
	                .findById(result.getDepartmentId())
	                .orElse(null);

	        TeacherCountByDepartment dto =
	                new TeacherCountByDepartment();

	        dto.setDepartmentId(result.getDepartmentId());
	        dto.setCount(result.getCount());

	        if(department != null) {
	            dto.setDepartmentName(department.getDepartmentName());
	        }

	        response.add(dto);
	    }

	    return response;
	}
	
	@Operation(
    	    summary = "Get complaints by status"
    	)
	@GetMapping("/complaints-by-status")
	public List<ComplaintCountByStatus> complaintsByStatus() {

	    Aggregation aggregation =
	            Aggregation.newAggregation(

	                    Aggregation.group("status")
	                            .count()
	                            .as("count"),

	                    Aggregation.project("count")
	                            .and("_id")
	                            .as("status")
	            );

	    AggregationResults<ComplaintCountByStatus> results =
	            mongoTemplate.aggregate(
	                    aggregation,
	                    "complaints",
	                    ComplaintCountByStatus.class);

	    return results.getMappedResults();
	}
	
	@GetMapping("/complaints-by-priority")
	public List<ComplaintCountByPriority> complaintsByPriority() {

	    Aggregation aggregation =
	            Aggregation.newAggregation(

	                    Aggregation.group("priority")
	                            .count()
	                            .as("count"),

	                    Aggregation.project("count")
	                            .and("_id")
	                            .as("priority")
	            );

	    AggregationResults<ComplaintCountByPriority> results =
	            mongoTemplate.aggregate(
	                    aggregation,
	                    "complaints",
	                    ComplaintCountByPriority.class);

	    return results.getMappedResults();
	}
	
	@Operation(
    	    summary = "Get room occupancy"
    	)
	@GetMapping("/room-occupancy")
	public List<RoomOccupancy> roomOccupancy() {

	    List<RoomOccupancy> response =
	            new ArrayList<>();

	    List<Room> rooms =
	            roomRepository.findAll();

	    for(Room room : rooms) {

	        int occupied =
	                studentRepository
	                .findByRoomId(room.getId())
	                .size();

	        RoomOccupancy dto =
	                new RoomOccupancy();

	        dto.setRoomId(room.getId());
	        dto.setRoomNumber(room.getRoomNo());
	        dto.setCapacity(room.getCapacity());
	        dto.setOccupied(occupied);
	        dto.setAvailable(
	                room.getCapacity() - occupied
	        );

	        response.add(dto);
	    }

	    return response;
	}

}
