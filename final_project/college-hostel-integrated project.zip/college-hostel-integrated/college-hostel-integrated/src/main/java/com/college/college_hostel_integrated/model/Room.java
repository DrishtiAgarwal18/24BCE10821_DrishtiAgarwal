package com.college.college_hostel_integrated.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.*;

@Document(collection = "rooms")
public class Room {

    @Id
    private String id;
    @NotBlank(message = "Room Number is required")
    private String roomNo;
    @NotNull
    @Min(1)
    private Integer capacity;

    public Room() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRoomNo() {
        return roomNo;
    }
    
    public Integer getCapacity() {
        return capacity;
    }

    public void setRoomNo(String roomNo) {
        this.roomNo = roomNo;
    }
    
    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }
}